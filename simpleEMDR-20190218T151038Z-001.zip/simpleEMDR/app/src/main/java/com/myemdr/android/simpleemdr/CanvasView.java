package com.myemdr.android.simpleemdr;

//package com.javacodegeeks.androidcanvasexample;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import java.sql.Time;
import java.util.Random;

public class CanvasView extends View {

    public int width;
    public int height;
    private Bitmap mBitmap;
    private Canvas mCanvas;
    private Path mPath;
    Context context;
    private Paint mPaint;
    private float mX, mY;
    private static final float TOLERANCE = 5;
    //Time temps = new Time();
    private int t = (int)System.currentTimeMillis();
    //private int e ;
    private static int T = 1024/2;
    private double largeur;
    private double hauteur;
    private double pi = Math.PI;
    private float htmp;
    private float ltmp;
    private int tempo;
    private static int TEMPO = 2;
    private double dt;

    public CanvasView(Context c, AttributeSet attrs) {
        super(c, attrs);
        context = c;

        // we set a new Path
        mPath = new Path();

        // and we set a new Paint with the desired attributes
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
        mPaint.setColor(Color.parseColor("#FFDEAD"));//Color.BLACK); beige : "#F5F5DC" ; navajowhite : "#FFDEAD"
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeJoin(Paint.Join.MITER);
        mPaint.setStrokeWidth(9f);

        // test
        DisplayMetrics ecran = new DisplayMetrics();
        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        windowManager.getDefaultDisplay().getMetrics(ecran);
        largeur = ecran.widthPixels;
        hauteur = ecran.heightPixels;
        // fin test
    }

    // override onSizeChanged
    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        // your Canvas will draw onto the defined Bitmap
        mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(mBitmap);

    }

    // override onDraw
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // draw the mPath with the mPaint on the canvas when onDraw
        canvas.drawPath(mPath, mPaint);

        // test
        canvas.drawCircle(ltmp, htmp, 10, mPaint);

        update();

        /*
        tempo = (int) (TEMPO * (1 + 0.5 * Math.sin(2 * pi * t / (4 * T))));
        tempo = 100;
        try {
            Thread.sleep(tempo);
        } catch (InterruptedException exception) {
            exception.printStackTrace();
        }
        */

        invalidate();  // Force a re-draw
        // fin test
    }

    protected void update() {
        t = t + 1;

        dt = 2 * pi * t / T + 50*Math.cos(2 * pi * t / (16 * T)) ;

        htmp = (float) (hauteur / 2 * (1 + 0.85 * Math.sin(dt)));
        ltmp = (float) (largeur / 2 * (1 + 2 * 0.85 * Math.sin(dt) * Math.cos(dt)));

        //this.mCanvas.drawCircle(ltmp, htmp, 10, mPaint);

        /*System.out.println(t);
        System.out.println(dt);
        System.out.println(dt);
        System.out.println(dt);
        System.out.println(dt);
        System.out.println(htmp);
        System.out.println(ltmp);*/
    }
}

/*    protected void boucler(){
        // TEST
        while(true) {
            }
        // FIN TEST
    }*/
/*

    // when ACTION_DOWN start touch according to the x,y values
    private void startTouch(float x, float y) {
        mPath.moveTo(x, y);
        mX = x;
        mY = y;
    }

    // when ACTION_MOVE move touch according to the x,y values
    private void moveTouch(float x, float y) {
        float dx = Math.abs(x - mX);
        float dy = Math.abs(y - mY);
        if (dx >= TOLERANCE || dy >= TOLERANCE) {
            mPath.quadTo(mX, mY, (x + mX) / 2, (y + mY) / 2);
            mX = x;
            mY = y;
        }
    }

    public void clearCanvas() {
        mPath.reset();
        invalidate();
    }

    // when ACTION_UP stop touch
    private void upTouch() {
        mPath.lineTo(mX, mY);
    }

    //override the onTouchEvent
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startTouch(x, y);
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:
                moveTouch(x, y);
                invalidate();
                break;
            case MotionEvent.ACTION_UP:
                upTouch();
                invalidate();
                break;
        }
        return true;
    }
}
*/

/*
class CanvasView {

}
*/
